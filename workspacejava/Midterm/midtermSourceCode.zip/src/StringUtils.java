
public class StringUtils {
	
	/**
	 * copy
			Write a method String copy(String currentString, int startPosition, int onePastLastPosition).  
			This method returns a substring of currentString, including startPosition, but ending before onePastLastPosition.  
			For example, copy(�abcd�, 1, 3) returns the String �bc� 
	* @param currentString
	* @param startPosition
	* @param onePastLastPosition
	* @return
	*/
			
	public static String copy(String currentString, int startPosition, int onePastLastPosition) {
		int currentStringLength = currentString.length();
		String subCurrentString = currentString.substring(startPosition, onePastLastPosition);
		
		return subCurrentString;	
	}	
	
	/**cut
			Write a method String cut(String currentString, int  startPosition, int onePastLastPosition).  
			This method returns a String constructed by starting with currentString, 
			and removes the letters starting with startPosition and stopping before onePastLastPosition.  
			For example, cut(�abcd�, 1, 3) returns the String �ad�
	* @param currentString
	* @param startPosition
	* @param onePastLastPosition
	* @return
	*/
	
	public static String cut(String currentString, int startPosition, int onePastLastPosition) {
		// identify character at startposition
		String startChar = currentString.substring(startPosition);
		// remove startposition character from original string
		String truncateCurrentString = currentString.replaceAll(startChar, "");
		// identify character at lastposition
		String lastChar = currentString.substring(onePastLastPosition);
		// remove last character from orginal string
		truncateCurrentString = currentString.replaceAll(lastChar, "");
	
		return truncateCurrentString;
	}	
	
	/**paste
			Write a method String paste(String currentString, int insertBefore, String stringToInsert).  
			This method returns the String constructed by inserting stringToInsert into currentString before position insertBefore.  
			For example, paste(�ad�, 1, �bc�) returns the String �abcd� 
			
	* @param currentString
	* @param insertBefore
	* @param stringToInsert
	* @return
	*/
	
	public static String paste(String currentString, int insertBefore, String stringToInsert) {
		String insertCurrentString = currentString.insert(insertBefore, stringToInsert);
		
		return insertCurrentString;		
	}

}
